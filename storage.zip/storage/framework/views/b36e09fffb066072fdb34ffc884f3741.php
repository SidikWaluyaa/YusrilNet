<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Page Heading -->
     <?php $__env->slot('header', null, []); ?> 
        <h1 class="h3 mb-4 text-gray-800"><?php echo e(__('Selesaikan Pembayaran')); ?></h1>
     <?php $__env->endSlot(); ?>

    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-lg-6">

                <!-- Card untuk Detail Pembayaran -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Detail Pembelian Anda</h6>
                    </div>
                    <div class="card-body text-center">

                        <p class="lead text-gray-800">Anda akan melakukan pembayaran untuk:</p>

                        <!-- Detail Paket dan Harga -->
                        <div class="my-4">
                            <h4 class="font-weight-bold"><?php echo e($order->paket->nama); ?></h4>
                            <p class="h5 text-gray-600">Total Harga:</p>
                            <p class="h3 font-weight-bold text-success">
                                Rp <?php echo e(number_format($order->harga, 0, ',', '.')); ?>

                            </p>
                        </div>

                        <hr>

                        <p class="text-muted small">
                            Klik tombol di bawah ini untuk melanjutkan ke proses pembayaran yang aman melalui Midtrans.
                        </p>

                        <!-- Tombol Pembayaran -->
                        <button id="pay-button" class="btn btn-primary btn-icon-split btn-lg">
                            <span class="icon text-white-50">
                                <i class="fas fa-credit-card"></i>
                            </span>
                            <span class="text">Bayar Sekarang</span>
                        </button>

                        <!-- Indikator Loading (ditampilkan oleh JavaScript) -->
                        <div id="loading-spinner" class="mt-3" style="display: none;">
                            <div class="spinner-border text-primary" role="status">
                                <span class="sr-only">Memuat...</span>
                            </div>
                            <p class="mt-2">Mempersiapkan pembayaran...</p>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
    
    <script src="https://app.sandbox.midtrans.com/snap/snap.js"
        data-client-key="<?php echo e(config('services.midtrans.clientKey')); ?>"></script>
    <script type="text/javascript">
        const payButton = document.getElementById('pay-button');

        payButton.addEventListener('click', function() {
            payButton.disabled = true;
            payButton.textContent = 'Memuat...';

            window.snap.pay('<?php echo e($snapToken); ?>', {
                onSuccess: function(result) {
                    updateOrderStatus('success');
                    alert("Pembayaran berhasil! Kode voucher akan segera dikirim ke email Anda.");
                    window.location.href = "<?php echo e(route('user.orders.show', $order->id)); ?>";
                },
                onPending: function(result) {
                    updateOrderStatus('pending');
                    alert("Pembayaran Anda tertunda. Silakan selesaikan pembayaran sesuai instruksi.");
                    window.location.href = "<?php echo e(route('user.orders.show', $order->id)); ?>";
                },
                onError: function(result) {
                    updateOrderStatus('error');
                    alert("Pembayaran gagal. Silakan coba lagi.");
                    payButton.disabled = false;
                    payButton.textContent = 'Bayar Sekarang';
                },
                onClose: function() {
                    alert('Anda menutup popup tanpa menyelesaikan pembayaran.');
                    payButton.disabled = false;
                    payButton.textContent = 'Bayar Sekarang';
                }
            });
        });

        function updateOrderStatus(status) {
            fetch('<?php echo e(route('user.orders.updateStatus')); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    body: JSON.stringify({
                        order_id: '<?php echo e($order->id); ?>',
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => console.log('Update status response:', data))
                .catch(error => console.error('Error updating status:', error));
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sidiknet\resources\views/user/orders/payment.blade.php ENDPATH**/ ?>
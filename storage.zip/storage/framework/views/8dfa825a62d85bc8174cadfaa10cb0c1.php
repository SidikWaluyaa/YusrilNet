<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <!-- Header -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard Admin</h1>
        </div>

        <!-- Welcome Card -->
        <div class="alert alert-primary d-flex justify-content-between align-items-center shadow mb-4">
            <div>
                <h5 class="mb-1">Selamat datang kembali, Admin!</h5>
                <p class="mb-0">Kelola semua layanan dari dashboard ini</p>
            </div>
            <i class="fas fa-tools fa-2x opacity-25"></i>
        </div>

        <!-- Stats Cards -->
        <div class="row">
            <!-- Paket -->
            <div class="col-md-4 mb-4">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                    Total Paket</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($pakets); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-box fa-2x text-primary"></i>
                            </div>
                        </div>
                        <a href="<?php echo e(route('admin.pakets.index')); ?>" class="small mt-2 d-block text-primary">Kelola
                            Paket</a>
                    </div>
                </div>
            </div>

            <!-- Voucher -->
            <div class="col-md-4 mb-4">
                <div class="card border-left-success shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                    Total Voucher</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($vouchers); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-ticket-alt fa-2x text-success"></i>
                            </div>
                        </div>
                        <a href="<?php echo e(route('admin.vouchers.index')); ?>" class="small mt-2 d-block text-success">Kelola
                            Voucher</a>
                    </div>
                </div>
            </div>

            <!-- Order -->
            <div class="col-md-4 mb-4">
                <div class="card border-left-info shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                    Total Order</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($orders); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-shopping-cart fa-2x text-info"></i>
                            </div>
                        </div>
                        <a href="<?php echo e(route('admin.orders.index')); ?>" class="small mt-2 d-block text-info">Kelola
                            Order</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card bg-primary text-white shadow">
                    <div class="card-body">
                        Kelola Paket
                        <div class="text-white-50 small">Tambah, edit, atau hapus paket</div>
                    </div>
                    <div class="card-footer text-center">
                        <a href="<?php echo e(route('admin.pakets.index')); ?>" class="btn btn-light btn-sm">Akses Sekarang</a>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4">
                <div class="card bg-success text-white shadow">
                    <div class="card-body">
                        Kelola Voucher
                        <div class="text-white-50 small">Buat atau atur voucher</div>
                    </div>
                    <div class="card-footer text-center">
                        <a href="<?php echo e(route('admin.vouchers.index')); ?>" class="btn btn-light btn-sm">Akses Sekarang</a>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4">
                <div class="card bg-info text-white shadow">
                    <div class="card-body">
                        Kelola Order
                        <div class="text-white-50 small">Lihat dan kelola pesanan</div>
                    </div>
                    <div class="card-footer text-center">
                        <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-light btn-sm">Akses Sekarang</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sidiknet\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
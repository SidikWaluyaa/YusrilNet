<?php
    $user = auth()->user();
?>

<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

    <!-- Sidebar Toggle (Topbar) -->
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>

    

    <!-- Topbar Navbar -->
    <ul class="navbar-nav ml-auto">

        

        <div class="topbar-divider d-none d-sm-block"></div>

        <!-- User Info -->
        <?php if(auth()->guard()->check()): ?>
            <li class="nav-item dropdown no-arrow">
                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown"
                    aria-haspopup="true" aria-expanded="false">
                    <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo e($user->name); ?></span>
                    <div class="img-profile rounded-circle bg-primary text-white d-flex align-items-center justify-content-center"
                        style="width: 32px; height: 32px; font-size: 14px;">
                        <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                    </div>
                </a>
                <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                    <div class="dropdown-item-text text-center">
                        <div class="font-weight-bold"><?php echo e($user->name); ?></div>
                        <div class="small text-gray-500"><?php echo e($user->email); ?></div>
                    </div>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>">
                        <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                        Profile
                    </a>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault(); this.closest('form').submit();">
                            <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                            Logout
                        </a>
                    </form>
                </div>
            </li>
        <?php endif; ?>

    </ul>
</nav>
<?php /**PATH C:\laragon\www\sidiknet\resources\views/components/topbar.blade.php ENDPATH**/ ?>
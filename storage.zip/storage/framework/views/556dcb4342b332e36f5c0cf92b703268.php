<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title', 'Tambah Paket'); ?>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card shadow rounded">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0"><i class="fas fa-plus-circle me-2"></i> Tambah Paket</h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.pakets.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            
                            <div class="mb-3">
                                <label for="nama" class="form-label fw-semibold">Nama Paket</label>
                                <input type="text" name="nama" class="form-control" required>
                            </div>

                            
                            <div class="mb-3">
                                <label for="price" class="form-label fw-semibold">Harga (Rp)</label>
                                <input type="number" name="price" class="form-control" required>
                            </div>

                            
                            <div class="mb-3">
                                <label for="duration" class="form-label fw-semibold">Durasi (Jam)</label>
                                <input type="number" name="duration" class="form-control" required>
                            </div>

                            
                            <div class="mb-3">
                                <label for="deskripsi" class="form-label fw-semibold">Deskripsi</label>
                                <textarea name="deskripsi" class="form-control" rows="3" required></textarea>
                            </div>

                            
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Detail Paket</label>
                                <div id="detail-wrapper">
                                    <div class="input-group mb-2">
                                        <input type="text" name="detail_paket[]" class="form-control mr-2"
                                            placeholder="Detail Paket" required>
                                        <button type="button" class="btn btn-danger remove-detail">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </div>
                                <button type="button" class="btn btn-success btn-sm" id="add-detail">
                                    <i class="fas fa-plus"></i> Tambah Detail
                                </button>
                            </div>

                            
                            <div class="mb-3">
                                <label for="available" class="form-label fw-semibold">Status Ketersediaan</label>
                                <select name="available" class="form-select">
                                    <option value="1">Tersedia</option>
                                    <option value="0">Tidak Tersedia</option>
                                </select>
                            </div>

                            
                            <div class="d-flex justify-content-between">
                                <a href="<?php echo e(route('admin.pakets.index')); ?>" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left me-1"></i> Kembali
                                </a>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save me-1"></i> Simpan Paket
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <script>
        document.getElementById('add-detail').onclick = function() {
            const wrapper = document.getElementById('detail-wrapper');
            const html = `
                <div class="input-group mb-2">
                    <input type="text" name="detail_paket[]" class="form-control" placeholder="Detail Paket" required>
                    <button type="button" class="btn btn-danger remove-detail">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
            wrapper.insertAdjacentHTML('beforeend', html);
        };

        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('remove-detail') || e.target.closest('.remove-detail')) {
                e.target.closest('.input-group').remove();
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sidiknet\resources\views/pakets/create.blade.php ENDPATH**/ ?>
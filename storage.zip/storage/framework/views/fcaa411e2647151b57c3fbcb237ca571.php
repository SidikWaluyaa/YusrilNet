<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deskripsi Paket</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <div class="container py-4">
        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-dark"><?php echo e($paket->nama); ?></h1>
            <a href="<?php echo e(route('welcome')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm">
                <i class="fas fa-arrow-left fa-sm text-white-50"></i> Kembali
            </a>
        </div>

        <div class="row">
            <!-- Kolom Kiri: Detail Lengkap Paket -->
            <div class="col-lg-7">
                <div class="card shadow mb-4">
                    <!-- Card Header -->
                    <div class="card-header py-3">
                        <h6 class="m-0 fw-bold text-primary">Detail Paket</h6>
                    </div>
                    <!-- Card Body -->
                    <div class="card-body">
                        <div class="mb-4">
                            <h6 class="fw-bold">Deskripsi</h6>
                            <button type="button" class="btn btn-outline-primary btn-sm" data-bs-toggle="modal"
                                data-bs-target="#deskripsiModal">
                                <i class="fas fa-info-circle me-2"></i>Lihat Deskripsi Lengkap
                            </button>
                        </div>

                        <div>
                            <h6 class="fw-bold">Yang Akan Anda Dapatkan</h6>
                            <?php
                                // Tambahkan pengecekan untuk memastikan $paket->detail_paket tidak null
                                $details = $paket->detail_paket ? json_decode($paket->detail_paket) : [];
                            ?>

                            <?php if(is_array($details) && count($details) > 0): ?>
                                <ul class="list-group list-group-flush">
                                    <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item d-flex align-items-center">
                                            <i class="fas fa-check-circle text-success me-2"></i>
                                            <span><?php echo e($detail); ?></span>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php else: ?>
                                <p class="text-muted">Detail tidak tersedia.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Kolom Kanan: Info Ringkas & Tombol Aksi -->
            <div class="col-lg-5">
                <!-- Card Harga & Durasi -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 fw-bold text-primary">Informasi</h6>
                    </div>
                    <div class="card-body">
                        <!-- Harga -->
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <span class="text-muted">Harga</span>
                            <span class="h5 fw-bold text-dark mb-0">Rp
                                <?php echo e(number_format($paket->price, 0, ',', '.')); ?></span>
                        </div>
                        <hr class="my-2">
                        <!-- Durasi -->
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <span class="text-muted">Durasi</span>
                            <span class="fw-bold text-dark"><?php echo e($paket->duration); ?> Jam/Hari</span>
                        </div>
                    </div>
                </div>

                <!-- Card Status & Aksi Beli -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 fw-bold text-primary">Status & Pembelian</h6>
                    </div>
                    <div class="card-body text-center">
                        <?php
                            $jumlahTersedia = $paket->vouchers
                                ->where('status', 'aktif')
                                ->where('available', 1)
                                ->count();
                        ?>

                        <h6 class="fw-bold">Ketersediaan Voucher</h6>
                        <?php if($jumlahTersedia > 0): ?>
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle me-1"></i>
                                <strong><?php echo e($jumlahTersedia); ?></strong> Voucher Tersedia
                            </div>
                            <p>Segera lakukan pembelian sebelum voucher habis.</p>
                            <a href="<?php echo e(route('user.orders.beli', $paket->id)); ?>"
                                class="btn btn-success d-grid gap-2 mb-2">
                                <span>
                                    <i class="fas fa-shopping-cart me-2"></i>
                                    Beli Sekarang
                                </span>
                            </a>
                        <?php else: ?>
                            <div class="alert alert-danger">
                                <i class="fas fa-times-circle me-1"></i>
                                Voucher Tidak Tersedia
                            </div>
                            <p>Mohon maaf, saat ini voucher untuk paket ini sudah habis.</p>
                            <button class="btn btn-secondary d-grid gap-2 mb-2" disabled>
                                <span>
                                    <i class="fas fa-ban me-2"></i>
                                    Voucher Habis
                                </span>
                            </button>
                        <?php endif; ?>
                        <a href="<?php echo e(route('welcome', $paket->id)); ?>" class="btn btn-info d-grid gap-2">
                            <span>Kembali Ke Daftar Paket</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Deskripsi -->
    <div class="modal fade" id="deskripsiModal" tabindex="-1" aria-labelledby="deskripsiModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deskripsiModalLabel">
                        <i class="fas fa-info-circle text-primary me-2"></i>
                        Deskripsi Lengkap - <?php echo e($paket->nama); ?>

                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <h6 class="fw-bold text-primary mb-3">
                            <i class="fas fa-file-text me-2"></i>Detail Deskripsi
                        </h6>
                        <p class="lead"><?php echo e($paket->deskripsi); ?></p>
                    </div>

                    <hr>

                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="fw-bold text-success">
                                <i class="fas fa-tag me-2"></i>Harga
                            </h6>
                            <p class="h5 text-success">Rp <?php echo e(number_format($paket->price, 0, ',', '.')); ?></p>
                        </div>
                        <div class="col-md-6">
                            <h6 class="fw-bold text-info">
                                <i class="fas fa-clock me-2"></i>Durasi
                            </h6>
                            <p class="h6 text-info"><?php echo e($paket->duration); ?> Jam/Hari</p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-2"></i>Tutup
                    </button>
                    <?php if($jumlahTersedia > 0): ?>
                        <a href="<?php echo e(route('user.orders.beli', $paket->id)); ?>" class="btn btn-success">
                            <i class="fas fa-shopping-cart me-2"></i>Beli Sekarang
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php /**PATH C:\laragon\www\sidiknet\resources\views/publicdeskripsi.blade.php ENDPATH**/ ?>
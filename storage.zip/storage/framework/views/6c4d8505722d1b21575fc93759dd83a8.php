<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Page Heading -->
     <?php $__env->slot('header', null, []); ?> 
        <h1 class="h3 mb-4 text-gray-800"><?php echo e(__('Detail Pesanan')); ?></h1>
     <?php $__env->endSlot(); ?>

    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-lg-8">

                <!-- Card untuk Detail Pesanan -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-primary">Informasi Pesanan Anda</h6>
                        
                    </div>
                    <div class="card-body">

                        
                        <dl class="row">

                            <dt class="col-sm-3"><i class="fas fa-user fa-fw mr-2 text-gray-500"></i>Nama Pelanggan</dt>
                            <dd class="col-sm-9"><?php echo e($order->nama); ?></dd>

                            <dt class="col-sm-3"><i class="fas fa-envelope fa-fw mr-2 text-gray-500"></i>Email</dt>
                            <dd class="col-sm-9"><?php echo e($order->email); ?></dd>

                            <dt class="col-sm-3"><i class="fas fa-box fa-fw mr-2 text-gray-500"></i>Paket</dt>
                            <dd class="col-sm-9 font-weight-bold"><?php echo e($order->paket->nama); ?></dd>

                            <dt class="col-sm-3"><i class="fas fa-tags fa-fw mr-2 text-gray-500"></i>Total Harga</dt>
                            <dd class="col-sm-9 h5 font-weight-bold text-success">Rp
                                <?php echo e(number_format($order->harga, 0, ',', '.')); ?></dd>

                        </dl>

                        <hr>

                        
                        <h6 class="font-weight-bold"><i class="fas fa-key fa-fw mr-2 text-gray-500"></i>Kredensial Akses
                        </h6>

                        <?php if($order->voucher && $order->status == 'terkirim'): ?>
                            <div class="alert alert-info mt-3">
                                <p class="mb-0">Gunakan informasi di bawah ini untuk login.</p>
                                <hr>
                                <dl class="row mb-0">
                                    <dt class="col-sm-3">Username:</dt>
                                    <dd class="col-sm-9 font-weight-bold"><?php echo e($order->voucher->username); ?></dd>

                                    <dt class="col-sm-3">Password:</dt>
                                    <dd class="col-sm-9 font-weight-bold"><?php echo e($order->voucher->password); ?></dd>
                                </dl>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-warning mt-3">
                                Kredensial akan tersedia di sini setelah pembayaran Anda berhasil diverifikasi dan
                                berstatus 'Selesai'.
                            </div>
                        <?php endif; ?>

                    </div>
                    <div class="card-footer text-right">
                        <a href="<?php echo e(route('user.orders.index')); ?>" class="btn btn-secondary btn-icon-split">
                            <span class="icon text-white-50">
                                <i class="fas fa-arrow-left"></i>
                            </span>
                            <span class="text">Kembali ke Daftar Order</span>
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sidiknet\resources\views/user/orders/show.blade.php ENDPATH**/ ?>
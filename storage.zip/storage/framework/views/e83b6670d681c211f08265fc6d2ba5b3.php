<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        .main-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        .voucher-card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            border: none;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .voucher-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background: linear-gradient(135deg, #6366F1 0%, #4F46E5 100%);
            color: white;
            padding: 20px;
            font-weight: 600;
            font-size: 20px;
            border-bottom: none;
            position: relative;
        }

        .header-pattern {
            position: absolute;
            inset: 0;
            opacity: 0.1;
            background-image: url("data:image/svg+xml,%3Csvg width='100' height='100' ... %3E%3C/svg%3E");
        }

        .card-body {
            padding: 30px;
        }

        .voucher-title {
            color: #1E293B;
            font-weight: 700;
            font-size: 24px;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid #e5e7eb;
        }

        .info-row {
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }

        .info-label {
            font-weight: 600;
            color: #64748B;
            width: 120px;
            display: flex;
            align-items: center;
        }

        .info-label i {
            margin-right: 10px;
            color: #4F46E5;
        }

        .info-value {
            flex: 1;
            font-weight: 500;
        }

        .badge {
            font-size: 14px;
            padding: 8px 12px;
            border-radius: 8px;
            font-weight: 500;
        }

        .bg-success {
            background-color: #10B981 !important;
        }

        .bg-danger {
            background-color: #EF4444 !important;
        }

        .btn-back {
            background: #4F46E5;
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-back:hover {
            background: #4338CA;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
        }

        .credentials-box {
            background-color: #F8FAFC;
            border-radius: 12px;
            padding: 20px;
            margin: 25px 0;
            border: 1px dashed #CBD5E1;
        }

        .copy-btn {
            cursor: pointer;
            color: #4F46E5;
            background: none;
            border: none;
            padding: 0;
            font-size: 16px;
        }

        .copy-btn:hover {
            color: #4338CA;
        }

        .footer-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e5e7eb;
        }
    </style>

    <div class="main-container">
        <div class="voucher-card card">
            <div class="card-header">
                <div class="header-pattern"></div>
                <i class="fas fa-ticket-alt me-2"></i> Detail Voucher
            </div>

            <div class="card-body">
                <h2 class="voucher-title"><?php echo e($voucher->nama); ?></h2>

                <div class="credentials-box">
                    <div class="info-row">
                        <div class="info-label"><i class="fas fa-user"></i> Username</div>
                        <div class="info-value"><?php echo e($voucher->username); ?></div>
                        <button class="copy-btn" onclick="copyToClipboard('<?php echo e($voucher->username); ?>')">
                            <i class="fas fa-copy"></i>
                        </button>
                    </div>
                    <div class="info-row mb-0">
                        <div class="info-label"><i class="fas fa-key"></i> Password</div>
                        <div class="info-value"><?php echo e($voucher->password); ?></div>
                        <button class="copy-btn" onclick="copyToClipboard('<?php echo e($voucher->password); ?>')">
                            <i class="fas fa-copy"></i>
                        </button>
                    </div>
                </div>

                <div class="info-row">
                    <div class="info-label"><i class="fas fa-circle-check"></i> Status</div>
                    <div class="info-value">
                        <span class="badge <?php echo e($voucher->status ? 'bg-success' : 'bg-danger'); ?>">
                            <i class="fas <?php echo e($voucher->status ? 'fa-check' : 'fa-times'); ?> me-1"></i>
                            <?php echo e($voucher->status ? 'Aktif' : 'Tidak Aktif'); ?>

                        </span>
                    </div>
                </div>

                <div class="info-row">
                    <div class="info-label"><i class="fas fa-box-open"></i> Available</div>
                    <div class="info-value">
                        <span class="badge <?php echo e($voucher->available ? 'bg-success' : 'bg-danger'); ?>">
                            <i class="fas <?php echo e($voucher->available ? 'fa-check' : 'fa-times'); ?> me-1"></i>
                            <?php echo e($voucher->available ? 'Tersedia' : 'Tidak Tersedia'); ?>

                        </span>
                    </div>
                </div>

                <div class="footer-actions">
                    <a href="<?php echo e(route('admin.vouchers.index')); ?>" class="btn btn-back">
                        <i class="fas fa-arrow-left me-2"></i> Kembali
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script>
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(() => {
                alert('Berhasil disalin ke clipboard!');
            });
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sidiknet\resources\views/vouchers/show.blade.php ENDPATH**/ ?>
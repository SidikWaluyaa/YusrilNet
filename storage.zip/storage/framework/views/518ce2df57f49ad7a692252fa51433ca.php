<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        .form-heading {
            font-weight: 700;
            color: #4e73df;
        }

        .card-custom {
            border-radius: 10px;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, .15);
            border: none;
            padding: 2rem;
            background-color: #fff;
            max-width: 700px;
            margin: 2rem auto;
        }

        .form-label {
            font-weight: 600;
        }

        .form-control-plaintext {
            padding-left: 0;
            font-weight: 600;
            color: #4e4e4e;
        }

        .btn-primary {
            background: linear-gradient(135deg, #6e8efb, #a777e3);
            border: none;
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, #5d7fe6, #9566d0);
        }
    </style>

    <div class="card card-custom">
        <h1 class="text-center form-heading mb-4">Tambah Voucher</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.vouchers.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label for="paket_id" class="form-label">Pilih Paket</label>
                <select name="paket_id" id="paket_id" class="form-control" required>
                    <option value="">-- Pilih Paket --</option>
                    <?php $__currentLoopData = $pakets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($paket->id); ?>" data-price="<?php echo e($paket->harga); ?>"
                            data-duration="<?php echo e($paket->durasi); ?>">
                            <?php echo e($paket->nama); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Harga Paket:</label>
                <p id="paket_price" class="form-control-plaintext"></p>
            </div>

            <div class="mb-3">
                <label class="form-label">Durasi Paket:</label>
                <p id="paket_duration" class="form-control-plaintext"></p>
            </div>

            <div class="mb-3">
                <label for="jumlah" class="form-label">Jumlah Voucher</label>
                <input type="number" name="jumlah" id="jumlah" class="form-control" min="1" value="1"
                    required>
            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary mr-2">Simpan Voucher</button>
                <a href="<?php echo e(route('admin.vouchers.index')); ?>" class="btn btn-secondary">Kembali</a>
            </div>
        </form>
    </div>

    <script>
        // Tampilkan harga & durasi dari paket yang dipilih
        const paketSelect = document.getElementById('paket_id');
        const paketPrice = document.getElementById('paket_price');
        const paketDuration = document.getElementById('paket_duration');

        paketSelect.addEventListener('change', function() {
            const selected = this.options[this.selectedIndex];
            const price = selected.getAttribute('data-price');
            const duration = selected.getAttribute('data-duration');

            paketPrice.textContent = price ? 'Rp ' + parseInt(price).toLocaleString() : '';
            paketDuration.textContent = duration ? duration + ' Jam' : '';
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sidiknet\resources\views/vouchers/create.blade.php ENDPATH**/ ?>
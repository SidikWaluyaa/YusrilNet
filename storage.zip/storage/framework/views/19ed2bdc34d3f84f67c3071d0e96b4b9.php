<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('header', 'Daftar Order'); ?>

    <div class="container-fluid">
        
        <div class="mb-4 d-flex justify-content-between align-items-center flex-wrap">
            <div>
                <h1 class="h3 text-gray-800 mb-0">Daftar Order</h1>
                <small class="text-muted">Kelola semua pesanan dalam sistem</small>
            </div>

            <form action="<?php echo e(route('admin.orders.print')); ?>" method="GET" target="_blank" class="mt-2 mt-md-0">
                <div class="d-flex flex-wrap gap-2 align-items-center">
                    <select name="paket_id" class="form-select mb-2">
                        <option value="">-- Semua Paket --</option>
                        <?php $__currentLoopData = \App\Models\Paket::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($paket->id); ?>"><?php echo e($paket->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <input type="date" name="tanggal_mulai" required class="form-control mb-2">
                    <input type="date" name="tanggal_akhir" required class="form-control mb-2">

                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-print me-1"></i> Cetak PDF
                    </button>
                </div>
            </form>
        </div>

        
        <?php if($orders->count() > 0): ?>
            <div class="alert alert-info shadow-sm">
                <i class="fas fa-info-circle me-2"></i>
                Ditemukan <strong><?php echo e($orders->count()); ?></strong> order yang masuk
            </div>
        <?php else: ?>
            <div class="alert alert-danger shadow-sm">
                <i class="fas fa-exclamation-circle me-2"></i>
                Tidak ada data order yang ditemukan
            </div>
        <?php endif; ?>

        
        <div class="card shadow mb-4">
            
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Data Pesanan</h6>

                
                <?php if($orders->count() > 0): ?>
                    <form action="<?php echo e(route('admin.orders.deleteAll')); ?>" method="POST"
                        onsubmit="return confirm('APAKAH ANDA YAKIN?\nSemua data order akan dihapus permanen dan tidak dapat dikembalikan. ID akan direset ke 1.');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">
                            <i class="fas fa-exclamation-triangle me-1"></i>
                            Hapus Semua & Reset ID
                        </button>
                    </form>
                <?php endif; ?>
            </div>

            <div class="card-body table-responsive">
                <table class="table table-bordered table-hover mb-0">
                    <thead class="bg-primary text-white text-center">
                        <tr>
                            <th>ID</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Paket</th>
                            <th>Username / Password</th>
                            <th>Harga</th>
                            <th>Status</th>
                            <th>Tanggal</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($order->id); ?></td>
                                <td><?php echo e($order->nama); ?></td>
                                <td><?php echo e($order->email); ?></td>
                                <td><?php echo e($order->paket->nama); ?></td>
                                <td>
                                    <?php if($order->voucher): ?>
                                        <span class="badge bg-light text-dark border border-secondary">
                                            <?php echo e($order->voucher->username); ?> / <?php echo e($order->voucher->password); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="text-muted">N/A</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-primary fw-semibold">Rp <?php echo e(number_format($order->harga, 0, ',', '.')); ?>

                                </td>
                                <td class="text-center">
                                    <span
                                        class="badge <?php echo e($order->status == 'selesai' || $order->status == 'terkirim' ? 'bg-success' : 'bg-warning'); ?>">
                                        
                                        <i
                                            class="fas <?php echo e($order->status == 'selesai' || $order->status == 'terkirim' ? 'fa-check-circle' : 'fa-clock'); ?>"></i>
                                        <?php echo e(ucfirst($order->status)); ?>

                                    </span>
                                </td>
                                <td>
                                    <?php echo e($order->created_at->format('d M Y')); ?>

                                    <div class="text-muted small"><?php echo e($order->created_at->format('H:i')); ?></div>
                                </td>
                                <td class="text-center">
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('user.orders.show', $order->id)); ?>"
                                            class="btn btn-info btn-sm" title="Lihat">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.orders.edit', $order->id)); ?>"
                                            class="btn btn-warning btn-sm" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('admin.orders.destroy', $order->id)); ?>" method="POST"
                                            onsubmit="return confirm('Hapus order ini?')" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-danger btn-sm" title="Hapus">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center py-5">
                                    <i class="fas fa-shopping-cart fa-3x text-muted mb-2"></i>
                                    <h5 class="mb-1">Tidak ada order</h5>
                                    <p class="text-muted">Belum ada data pemesanan untuk ditampilkan</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                
                <?php if(method_exists($orders, 'links')): ?>
                    <div class="d-flex justify-content-center mt-4">
                        <?php echo e($orders->links()); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sidiknet\resources\views/orders/index.blade.php ENDPATH**/ ?>
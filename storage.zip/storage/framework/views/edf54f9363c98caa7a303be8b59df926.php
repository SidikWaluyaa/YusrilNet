<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title', 'Edit Voucher'); ?>

    <style>
        .form-container {
            max-width: 700px;
            margin: 0 auto;
            padding: 30px;
        }

        .form-container h1 {
            text-align: center;
            margin-bottom: 30px;
            color: #2c3e50;
        }

        .card {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            padding: 25px;
            background-color: #fff;
        }

        .form-control-plaintext {
            background-color: #f8f9fa;
            padding: 0.375rem 0.75rem;
            border-radius: 0.375rem;
        }
    </style>

    <div class="container form-container">
        <div class="card">
            <h1>Edit Voucher</h1>
            <form action="<?php echo e(route('admin.vouchers.update', $voucher->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <!-- Pilih Paket -->
                <div class="mb-3">
                    <label for="paket_id" class="form-label">Pilih Paket</label>
                    <select name="paket_id" id="paket_id" class="form-select" required>
                        <option value="">-- Pilih Paket --</option>
                        <?php $__currentLoopData = $pakets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($paket->id); ?>" data-price="<?php echo e($paket->harga); ?>"
                                data-duration="<?php echo e($paket->durasi); ?>"
                                <?php echo e($paket->id == $voucher->paket_id ? 'selected' : ''); ?>>
                                <?php echo e($paket->nama); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <!-- Harga Paket -->
                <div class="mb-3">
                    <label class="form-label">Harga Paket:</label>
                    <p id="paket_price" class="form-control-plaintext">
                        Rp <?php echo e(number_format($voucher->price, 0, ',', '.')); ?>

                    </p>
                </div>

                <!-- Durasi Paket -->
                <div class="mb-3">
                    <label class="form-label">Durasi Paket:</label>
                    <p id="paket_duration" class="form-control-plaintext">
                        <?php echo e($voucher->duration); ?> Jam
                    </p>
                </div>

                <!-- Available -->
                <div class="mb-3">
                    <label for="available" class="form-label">Available</label>
                    <input type="number" class="form-control" name="available" value="<?php echo e($voucher->available); ?>"
                        required>
                </div>

                <!-- Status -->
                <div class="mb-3">
                    <label for="status" class="form-label">Status Voucher</label>
                    <select class="form-select" name="status" required>
                        <option value="aktif" <?php echo e($voucher->status == 'aktif' ? 'selected' : ''); ?>>Aktif</option>
                        <option value="nonaktif" <?php echo e($voucher->status == 'nonaktif' ? 'selected' : ''); ?>>Nonaktif
                        </option>
                    </select>
                </div>

                <!-- Tombol Submit -->
                <div class="d-flex justify-content-between">
                    <a href="<?php echo e(route('admin.vouchers.index')); ?>" class="btn btn-secondary">Kembali</a>
                    <button type="submit" class="btn btn-primary">Update Voucher</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const paketSelect = document.getElementById('paket_id');
        const paketPrice = document.getElementById('paket_price');
        const paketDuration = document.getElementById('paket_duration');

        paketSelect.addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            const price = selectedOption.getAttribute('data-price');
            const duration = selectedOption.getAttribute('data-duration');
            paketPrice.textContent = price ? 'Rp ' + parseInt(price).toLocaleString() : '';
            paketDuration.textContent = duration ? duration + ' Jam' : '';
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sidiknet\resources\views/vouchers/edit.blade.php ENDPATH**/ ?>
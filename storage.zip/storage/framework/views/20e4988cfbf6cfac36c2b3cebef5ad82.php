<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <h1 class="h3 mb-4 text-gray-800 text-center">Edit Paket</h1>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Formulir Edit Paket: <?php echo e($paket->nama); ?></h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.pakets.update', $paket->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        
                        <div class="mb-3">
                            <label for="nama" class="form-label">Nama Paket</label>
                            <input type="text" name="nama" id="nama" value="<?php echo e(old('nama', $paket->nama)); ?>"
                                class="form-control" required>
                        </div>

                        
                        <div class="mb-3">
                            <label for="price" class="form-label">Harga</label>
                            <input type="number" name="price" id="price"
                                value="<?php echo e(old('price', $paket->price)); ?>" class="form-control" required>
                        </div>

                        
                        <div class="mb-3">
                            <label for="duration" class="form-label">Durasi (dalam hari)</label>
                            <input type="number" name="duration" id="duration"
                                value="<?php echo e(old('duration', $paket->duration)); ?>" class="form-control" required>
                        </div>

                        
                        <div class="mb-3">
                            <label for="deskripsi" class="form-label">Deskripsi</label>
                            <textarea name="deskripsi" id="deskripsi" class="form-control" required><?php echo e(old('deskripsi', $paket->deskripsi)); ?></textarea>
                        </div>

                        
                        <div class="mb-3">
                            <label class="form-label">Detail Paket</label>
                            <div id="detail-fields-container">
                                <?php
                                    // Pastikan detail_paket adalah array, jika null atau tidak valid, buat array kosong
                                    $details = json_decode($paket->detail_paket, true);
                                    if (!is_array($details)) {
                                        $details = [];
                                    }
                                ?>

                                <?php $__empty_1 = true; $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="input-group mb-2">
                                        <input type="text" name="detail_paket[]" class="form-control"
                                            value="<?php echo e($detail); ?>">
                                        <button type="button" class="btn btn-danger remove-detail">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    
                                    <div class="input-group mb-2">
                                        <input type="text" name="detail_paket[]" class="form-control"
                                            placeholder="Contoh: Kecepatan 20 Mbps">
                                        <button type="button" class="btn btn-danger remove-detail">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <button type="button" id="add-detail" class="btn btn-success btn-sm mt-2">
                                <i class="fas fa-plus"></i> Tambah Detail
                            </button>
                        </div>

                        
                        <div class="mb-3">
                            <label for="available" class="form-label">Ketersediaan</label>
                            <select name="available" id="available" class="form-control">
                                <option value="1" <?php echo e($paket->available ? 'selected' : ''); ?>>Tersedia</option>
                                <option value="0" <?php echo e(!$paket->available ? 'selected' : ''); ?>>Tidak Tersedia
                                </option>
                            </select>
                        </div>

                        
                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Update Paket
                            </button>
                            <a href="<?php echo e(route('admin.pakets.index')); ?>" class="btn btn-secondary">
                                <i class="fas fa-arrow-left"></i> Kembali
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                // Fungsi untuk menambah input detail baru
                $('#add-detail').click(function() {
                    var newField = `
                    <div class="input-group mb-2">
                        <input type="text" name="detail_paket[]" class="form-control" placeholder="Detail baru">
                        <button type="button" class="btn btn-danger remove-detail">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>`;
                    $('#detail-fields-container').append(newField);
                });

                // Fungsi untuk menghapus input detail (menggunakan event delegation)
                // Ini penting agar tombol hapus pada elemen yang baru ditambahkan juga berfungsi
                $('#detail-fields-container').on('click', '.remove-detail', function() {
                    // Jangan hapus jika hanya tersisa satu input
                    if ($('#detail-fields-container .input-group').length > 1) {
                        $(this).closest('.input-group').remove();
                    } else {
                        alert('Minimal harus ada satu detail paket.');
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sidiknet\resources\views/pakets/edit.blade.php ENDPATH**/ ?>
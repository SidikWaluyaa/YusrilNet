<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yusril Net - Penyedia Voucher WiFi Terpercaya</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />

    <link rel="shortcut icon" href="<?php echo e(asset('Logo.png')); ?>" type="image/x-icon">
    <style>
        :root {
            --primary-color: #2563eb;
            --secondary-color: #4f46e5;
            --accent-color: #3b82f6;
            --light-color: #f3f4f6;
            --dark-color: #1e293b;
            --danger-color: #dc3545;
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            overflow-x: hidden;
            position: relative;
            line-height: 1.6;
        }

        /* === Gaya Navbar Utama === */
        /* === Gaya Navbar Utama === */
        .navbar {
            padding: 10px 0;
            transition: all 0.3s ease;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.07);
            background-color: white !important;
        }

        .navbar-brand {
            font-weight: 700;
            font-size: 1.6rem;
            color: var(--primary-color) !important;
        }

        .navbar-brand span {
            color: var(--secondary-color);
        }

        /* === Gaya SEMUA item di dalam .navbar-nav === */
        .navbar-nav .nav-link {
            font-weight: 500;
            color: var(--dark-color);
            margin: 0 2px;
            /* Sedikit ruang antar item */
            transition: all 0.3s ease;
            padding: 8px 15px !important;
            border-radius: 8px;
            white-space: nowrap;
            /* Mencegah teks turun baris */
        }

        /* Hapus background saat hover untuk tombol, karena sudah punya style sendiri */
        .navbar-nav .nav-link:not(.btn-login, .btn-register, .btn-logout):hover,
        .navbar-nav .nav-link:not(.btn-login, .btn-register, .btn-logout).active {
            color: var(--primary-color) !important;
            background-color: rgba(79, 70, 229, 0.05);
        }

        /* === Gaya Tombol Aksi (Login, Register, Logout) === */
        .btn-login,
        .btn-register,
        .btn-logout {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 8px 20px !important;
            border-radius: 50px !important;
            font-weight: 600;
            border: 2px solid transparent;
        }

        .btn-login {
            background-color: transparent;
            color: var(--primary-color) !important;
            border-color: var(--primary-color);
        }

        .btn-login:hover {
            background-color: var(--primary-color);
            color: white !important;
        }

        .btn-register {
            background-color: var(--primary-color);
            color: white !important;
            border-color: var(--primary-color);
        }

        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(79, 70, 229, 0.3);
        }

        .btn-logout {
            background-color: transparent;
            color: var(--danger-color) !important;
            border-color: var(--danger-color);
        }

        .btn-logout:hover {
            background-color: var(--danger-color);
            color: white !important;
        }

        /* === Perbaikan untuk Tampilan Mobile === */
        @media (max-width: 991.98px) {
            .navbar-collapse {
                margin-top: 15px;
                padding-top: 10px;
                border-top: 1px solid #eee;
            }

            .navbar-nav {
                text-align: center;
            }

            .navbar-nav .nav-link {
                margin-bottom: 8px;
            }
        }

        /* Hero Section Styles */
        #home {
            /* Ganti 'path/ke/gambar-anda.jpg' dengan URL atau path gambar Anda */
            background-image: url('gedung1.jpg');
            background-size: cover;
            /* Membuat gambar menutupi seluruh area section */
            background-position: center;
            /* Memposisikan gambar di tengah */
            background-repeat: no-repeat;
            /* Mencegah gambar berulang */
            color: white;
            padding: 100px 0 80px;
            position: relative;
            min-height: 100vh;
            display: flex;
            align-items: center;
        }

        /* Menambahkan lapisan (overlay) gelap di atas gambar */
        #home::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            /* Lapisan gradient gelap, sesuaikan opacity (angka terakhir) sesuai kebutuhan */
            background: rgba(0, 0, 0, 0.5);
            z-index: 0;
        }

        .hero-content {
            position: relative;
            z-index: 1;
            /* Pastikan konten berada di atas lapisan overlay */
            text-align: center;
        }

        .hero-content h1 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 20px;
            line-height: 1.2;
        }

        .hero-content p {
            font-size: 1.1rem;
            margin-bottom: 30px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }

        .hero-btn {
            padding: 12px 30px;
            font-size: 1rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            border-radius: 50px;
            background-color: white;
            color: #4F46E5;
            /* Ganti dengan kode warna primer Anda jika berbeda */
            border: none;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            text-decoration: none;
            display: inline-block;
        }

        .hero-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
            background-color: #f8f9fa;
            color: #4F46E5;
            /* Ganti dengan kode warna primer Anda jika berbeda */
        }

        .hero-content {
            position: relative;
            z-index: 1;
            text-align: center;
        }

        .hero-content h1 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 20px;
            line-height: 1.2;
        }

        .hero-content p {
            font-size: 1.1rem;
            margin-bottom: 30px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }

        .hero-btn {
            padding: 12px 30px;
            font-size: 1rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            border-radius: 50px;
            background-color: white;
            color: var(--primary-color);
            border: none;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            text-decoration: none;
            display: inline-block;
        }

        .hero-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
            background-color: #f8f9fa;
            color: var(--primary-color);
        }

        /* About Section Styles */
        #about {
            padding: 80px 0;
            background-color: var(--light-color);
        }

        .section-title {
            margin-bottom: 50px;
            text-align: center;
        }

        .section-title h2 {
            font-size: 2rem;
            font-weight: 700;
            color: var(--dark-color);
            margin-bottom: 15px;
            display: inline-block;
            position: relative;
        }

        .section-title h2::after {
            content: '';
            position: absolute;
            width: 60%;
            height: 3px;
            background-color: var(--primary-color);
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
        }

        .about-img {
            max-width: 100%;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .about-content p {
            font-size: 1rem;
            line-height: 1.8;
            margin-bottom: 20px;
            color: #4b5563;
        }

        .about-content h3 {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--dark-color);
            margin-bottom: 20px;
        }

        /* Services Section Styles */
        #services {
            padding: 80px 0;
            background-color: white;
        }

        .service-card {
            padding: 25px;
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
            transition: all 0.3s ease;
            height: 100%;
            text-align: center;
        }

        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.1);
        }

        .service-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            background-color: var(--primary-color);
            color: white;
            margin: 0 auto 20px;
        }

        .service-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 15px;
            color: var(--dark-color);
        }

        .service-desc {
            font-size: 0.95rem;
            line-height: 1.6;
            color: #6b7280;
        }

        /* Voucher Section Styles */
        #voucher {
            padding: 80px 0;
            background: linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%);
        }

        .pricing-card {
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            padding: 30px 20px;
            transition: all 0.3s ease;
            height: 100%;
            position: relative;
            overflow: hidden;
        }

        .pricing-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.1);
        }

        .pricing-card.popular {
            border: 2px solid var(--primary-color);
        }

        .popular-badge {
            position: absolute;
            top: 15px;
            right: -30px;
            transform: rotate(45deg);
            background-color: var(--primary-color);
            color: white;
            padding: 5px 35px;
            font-size: 0.7rem;
            font-weight: 600;
        }

        .pricing-header {
            text-align: center;
            margin-bottom: 25px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e5e7eb;
        }

        .pricing-title {
            font-size: 1.3rem;
            font-weight: 700;
            color: var(--dark-color);
            margin-bottom: 10px;
        }

        .pricing-price {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 5px;
        }

        .pricing-duration {
            font-size: 0.85rem;
            color: #6b7280;
            margin-bottom: 10px;
        }

        .voucher-status {
            display: inline-block;
            padding: 4px 12px;
            font-size: 0.75rem;
            font-weight: 500;
            border-radius: 20px;
            background-color: #dcfce7;
            color: #166534;
        }

        .voucher-status.unavailable {
            background-color: #fef2f2;
            color: #dc2626;
        }

        .pricing-features {
            margin-bottom: 25px;
            padding-left: 0;
        }

        .pricing-features li {
            list-style: none;
            padding: 6px 0;
            display: flex;
            align-items: center;
            color: #4b5563;
            font-size: 0.9rem;
        }

        .pricing-features li i {
            color: var(--primary-color);
            margin-right: 10px;
            font-size: 0.8rem;
        }

        .pricing-btn {
            display: block;
            width: 100%;
            padding: 10px 0;
            text-align: center;
            font-weight: 600;
            border-radius: 25px;
            background-color: var(--primary-color);
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border: 2px solid var(--primary-color);
            margin-bottom: 8px;
            font-size: 0.9rem;
        }

        .pricing-btn:hover {
            background-color: transparent;
            color: var(--primary-color);
        }

        .pricing-btn.secondary {
            background-color: transparent;
            color: var(--primary-color);
        }

        .pricing-btn.secondary:hover {
            background-color: var(--primary-color);
            color: white;
        }

        /* Footer Styles */
        footer {
            background-color: var(--dark-color);
            color: white;
            padding: 50px 0 20px;
        }

        .footer-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 20px;
        }

        .footer-contact {
            list-style: none;
            padding: 0;
        }

        .footer-contact li {
            padding: 8px 0;
            display: flex;
            align-items: center;
        }

        .footer-contact li i {
            margin-right: 10px;
            color: var(--primary-color);
            width: 20px;
        }

        .social-links a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
            margin-right: 10px;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .social-links a:hover {
            background-color: var(--primary-color);
            transform: translateY(-3px);
        }

        .footer-bottom {
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding-top: 20px;
            margin-top: 30px;
            text-align: center;
        }

        .footer-bottom p {
            font-size: 0.9rem;
            color: rgba(255, 255, 255, 0.7);
            margin: 0;
        }

        /* Back to Top Button */
        .back-to-top {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            z-index: 99;
            opacity: 0;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            text-decoration: none;
        }

        .back-to-top:hover {
            background-color: var(--secondary-color);
            transform: translateY(-3px);
            color: white;
        }

        .back-to-top.show {
            opacity: 1;
        }

        /* Mobile Responsive Adjustments */
        @media (max-width: 992px) {
            .hero-content h1 {
                font-size: 2.2rem;
            }

            .about-img {
                margin-bottom: 30px;
            }

            #about .row {
                flex-direction: column-reverse;
            }

            .pricing-card {
                margin-bottom: 30px;
            }
        }

        @media (max-width: 768px) {
            .hero-content h1 {
                font-size: 1.8rem;
            }

            .hero-content p {
                font-size: 1rem;
            }

            .section-title h2 {
                font-size: 1.8rem;
            }

            .navbar-brand {
                font-size: 1.4rem;
            }

            #home {
                padding: 80px 0 60px;
            }

            #about,
            #services,
            #voucher {
                padding: 60px 0;
            }

            .service-card {
                padding: 20px;
            }

            .pricing-card {
                padding: 25px 15px;
            }

            .pricing-price {
                font-size: 1.8rem;
            }

            .about-content h3 {
                font-size: 1.3rem;
            }
        }

        @media (max-width: 576px) {
            .hero-content h1 {
                font-size: 1.6rem;
            }

            .section-title h2 {
                font-size: 1.6rem;
            }

            .hero-btn {
                padding: 10px 25px;
                font-size: 0.9rem;
            }

            .container {
                padding-left: 15px;
                padding-right: 15px;
            }

            .pricing-card {
                padding: 20px 10px;
            }

            .service-card {
                padding: 15px;
            }

            .back-to-top {
                width: 40px;
                height: 40px;
                bottom: 15px;
                right: 15px;
            }

            .about-content .row .col-6 {
                margin-bottom: 15px;
            }
        }

        /* Custom Animation */
        .fadeInUp {
            animation: fadeInUp 1s;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Smooth scrolling */
        html {
            scroll-behavior: smooth;
        }
    </style>
</head>

<body>
    <!-- Navbar - Semua Menu di Kanan -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top">
        <div class="container">
            <!-- Logo di Kiri -->
            <a class="navbar-brand" href="#home">Yusril<span>Net</span></a>

            <!-- Tombol Toggler untuk Mobile -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Grup Menu di Kanan -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <!-- Gunakan ms-auto di sini untuk mendorong seluruh list ke kanan -->
                <ul class="navbar-nav ms-auto align-items-center">

                    <!-- Link Navigasi Biasa -->
                    <li class="nav-item">
                        <a class="nav-link" href="#home">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#services">Service</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#voucher">Voucher</a>
                    </li>

                    <!-- Separator untuk sedikit jarak sebelum tombol (opsional) -->
                    <li class="nav-item d-none d-lg-block">
                        <div style="width: 20px;"></div>
                    </li>

                    <!-- Tombol Aksi (Login/Register atau Dashboard/Logout) -->
                    <?php if(auth()->guard()->guest()): ?>
                        
                        <li class="nav-item">
                            <a class="nav-link btn-login" href="<?php echo e(route('login')); ?>">
                                <i class="fas fa-right-to-bracket me-2"></i>Login
                            </a>
                        </li>
                        <li class="nav-item ms-lg-2 mt-2 mt-lg-0">
                            <a class="nav-link btn-register" href="<?php echo e(route('register')); ?>">
                                <i class="fas fa-user-plus me-2"></i>Register
                            </a>
                        </li>
                    <?php else: ?>
                        
                        <li class="nav-item">
                            <?php
                                $user = auth()->user();
                            ?>
                            <a class="nav-link"
                                href="<?php echo e($user->role === 'admin' ? route('admin.dashboard') : route('user.dashboard')); ?>">
                                My Dashboard
                            </a>
                        </li>
                        <li class="nav-item ms-lg-2 mt-2 mt-lg-0">
                            <a class="nav-link btn-logout" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="fas fa-right-from-bracket me-2"></i>Logout
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Dashboard Section -->
    <section id="home">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="hero-content">
                        <h1 class="animate__animated animate__fadeInUp">Internet Cepat & Stabil Untuk Semua Kebutuhan
                            Anda</h1>
                        <p class="animate__animated animate__fadeInUp animate__delay-1s">Nikmati pengalaman internet
                            tanpa batas dengan voucher wifi Yusril Net. Kecepatan tinggi, koneksi stabil, dan harga
                            terjangkau untuk kebutuhan browsing, streaming, dan gaming Anda.</p>
                        <a href="#voucher"
                            class="btn hero-btn animate__animated animate__fadeInUp animate__delay-2s">Beli Voucher
                            Sekarang</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about">
        <div class="container">
            <div class="section-title">
                <h2>Tentang Kami</h2>
            </div>
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="about-content">
                        <h3>Yusril Net - Penyedia Jaringan Internet Terpercaya</h3>
                        <p>YusrilNet Sriwijaya adalah penyedia layanan internet lokal yang berdiri sejak tahun 2021,
                            berlokasi di Jl. Sriwijaya Gg. IX No.31,
                            RT04/RW10, Kel. Cigereleng, Kec. Regol, Kota Bandung.
                            YusrilNet hadir untuk menjawab tingginya kebutuhan masyarakat akan akses internet murah,
                            cepat, dan
                            mudah dijangkau.</p>
                        <p>Dengan teknologi terkini dan tim teknisi profesional, kami menjamin pengalaman internet
                            terbaik untuk semua kebutuhan Anda, baik untuk keperluan bisnis, pendidikan, maupun hiburan.
                        </p>
                        <div class="mt-4">
                            <div class="row">
                                <div class="col-6 col-md-4 mb-3">
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-wifi me-2 fs-4 text-primary"></i>
                                        <div>
                                            <h5 class="mb-0">10+</h5>
                                            <p class="mb-0 small">Hotspot</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6 col-md-4 mb-3">
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-users me-2 fs-4 text-primary"></i>
                                        <div>
                                            <h5 class="mb-0">100+</h5>
                                            <p class="mb-0 small">Pengguna</p>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 mb-4 mb-lg-0">
                    <div class="text-center">
                        <img src="<?php echo e(asset('logo.png')); ?>" alt="Logo" style="height: 300px;"
                            class="w-auto mx-auto mb-3">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services">
        <div class="container">
            <div class="section-title">
                <h2>Layanan Kami</h2>
            </div>
            <div class="row">
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="service-card">
                        <div class="service-icon">
                            <i class="fas fa-bolt"></i>
                        </div>
                        <h3 class="service-title">Kecepatan Tinggi</h3>
                        <p class="service-desc">Nikmati kecepatan internet hingga 5 Mbps yang memungkinkan Anda
                            browsing, streaming, dan download dengan cepat tanpa buffering.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="service-card">
                        <div class="service-icon">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h3 class="service-title">Keamanan Terjamin</h3>
                        <p class="service-desc">Koneksi wifi kami dilengkapi dengan sistem keamanan terkini yang
                            melindungi data dan privasi Anda saat online.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="service-card">
                        <div class="service-icon">
                            <i class="fas fa-signal"></i>
                        </div>
                        <h3 class="service-title">Jangkauan Luas</h3>
                        <p class="service-desc">Dengan hotspot yang tersebar, Anda dapat terhubung ke internet
                            Yusril Net di berbagai lokasi strategis.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="service-card">
                        <div class="service-icon">
                            <i class="fas fa-headset"></i>
                        </div>
                        <h3 class="service-title">Dukungan 24/7</h3>
                        <p class="service-desc">Tim dukungan pelanggan kami siap membantu Anda 24 jam sehari, 7 hari
                            seminggu untuk memastikan pengalaman internet terbaik.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="service-card">
                        <div class="service-icon">
                            <i class="fas fa-hand-holding-usd"></i>
                        </div>
                        <h3 class="service-title">Harga Terjangkau</h3>
                        <p class="service-desc">Kami menawarkan berbagai paket internet dengan harga yang terjangkau
                            dan sesuai dengan kebutuhan dan budget Anda.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="service-card">
                        <div class="service-icon">
                            <i class="fas fa-project-diagram"></i>
                        </div>
                        <h3 class="service-title">Solusi Korporasi</h3>
                        <p class="service-desc">Kami menyediakan solusi internet khusus untuk kebutuhan bisnis dan
                            perusahaan dengan layanan yang dapat disesuaikan.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="voucher">
        <div class="container">
            <div class="section-title">
                <h2>Paket Voucher</h2>
            </div>
            <div class="row">
                <?php $__currentLoopData = $pakets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-3 mb-4">
                        <div class="pricing-card">
                            <div class="pricing-header">
                                <h3 class="pricing-title"><?php echo e($paket->nama); ?></h3>
                                <div class="pricing-price">Rp <?php echo e(number_format($paket->price, 0, ',', '.')); ?></div>
                                <div class="pricing-duration"><?php echo e($paket->deskripsi); ?></div>
                                <?php
                                    $jumlahTersedia = $paket->vouchers
                                        ->where('status', 'aktif')
                                        ->where('available', 1)
                                        ->count();
                                ?>
                                <span class="voucher-status <?php echo e($jumlahTersedia > 0 ? '' : 'unavailable'); ?>">
                                    <?php echo e($jumlahTersedia); ?> Voucher Tersedia
                                </span>
                            </div>
                            <ul class="pricing-features">
                                <?php
                                    $details = $paket->detail_paket ? json_decode($paket->detail_paket) : [];
                                ?>
                                <?php if(is_array($details) && count($details) > 0): ?>
                                    <?php $__currentLoopData = array_slice($details, 0, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><i class="fas fa-check-circle"></i> <?php echo e($detail); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(count($details) > 3): ?>
                                        <li class="text-muted"><i class="fas fa-ellipsis-h"></i> Dan
                                            <?php echo e(count($details) - 3); ?> fitur lainnya...</li>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <li class="text-muted">Detail tidak tersedia</li>
                                <?php endif; ?>
                            </ul>
                            <div class="d-flex gap-2">
                                <button type="button" class="pricing-btn secondary" data-bs-toggle="modal"
                                    data-bs-target="#deskripsiModal<?php echo e($paket->id); ?>">
                                    <i class="fas fa-info-circle me-1"></i>Deskripsi
                                </button>
                                <?php if($jumlahTersedia > 0): ?>
                                    <a href="<?php echo e(route('user.orders.beli', $paket->id)); ?>" class="pricing-btn">
                                        <i class="fas fa-shopping-cart me-1"></i>Beli
                                    </a>
                                <?php else: ?>
                                    <button class="pricing-btn" disabled
                                        style="background-color: #6c757d; border-color: #6c757d;">
                                        <i class="fas fa-ban me-1"></i>Habis
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Modal Deskripsi untuk setiap paket -->
                    <div class="modal fade" id="deskripsiModal<?php echo e($paket->id); ?>" tabindex="-1"
                        aria-labelledby="deskripsiModalLabel<?php echo e($paket->id); ?>" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header"
                                    style="background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); color: white;">
                                    <h5 class="modal-title" id="deskripsiModalLabel<?php echo e($paket->id); ?>">
                                        <i class="fas fa-wifi me-2"></i>
                                        <?php echo e($paket->nama); ?> - Detail Lengkap
                                    </h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <!-- Deskripsi Paket -->
                                    <div class="mb-4">
                                        <h6 class="fw-bold text-primary mb-3">
                                            <i class="fas fa-file-text me-2"></i>Deskripsi Paket
                                        </h6>
                                        <div class="border-start border-primary border-3 ps-3">
                                            <p class="lead text-justify mb-0"><?php echo e($paket->deskripsi); ?></p>
                                        </div>
                                    </div>

                                    <hr>

                                    <!-- Info Harga dan Durasi -->
                                    <div class="row mb-4">
                                        <div class="col-md-6">
                                            <div class="card border-0 bg-light">
                                                <div class="card-body text-center py-3">
                                                    <h6 class="fw-bold text-success mb-2">
                                                        <i class="fas fa-tag me-2"></i>Harga
                                                    </h6>
                                                    <p class="h4 text-success mb-0">Rp
                                                        <?php echo e(number_format($paket->price, 0, ',', '.')); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="card border-0 bg-light">
                                                <div class="card-body text-center py-3">
                                                    <h6 class="fw-bold text-info mb-2">
                                                        <i class="fas fa-clock me-2"></i>Durasi
                                                    </h6>
                                                    <p class="h5 text-info mb-0"><?php echo e($paket->duration); ?> Jam</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Fitur Lengkap -->
                                    <div class="mb-4">
                                        <h6 class="fw-bold text-primary mb-3">
                                            <i class="fas fa-list-check me-2"></i>Yang Akan Anda Dapatkan
                                        </h6>
                                        <?php if(is_array($details) && count($details) > 0): ?>
                                            <div class="row">
                                                <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-md-6 mb-2">
                                                        <div class="d-flex align-items-center">
                                                            <i
                                                                class="fas fa-check-circle text-success me-2 flex-shrink-0"></i>
                                                            <span class="small"><?php echo e($detail); ?></span>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        <?php else: ?>
                                            <p class="text-muted">Detail fitur tidak tersedia.</p>
                                        <?php endif; ?>
                                    </div>

                                    <!-- Status Ketersediaan -->
                                    <div
                                        class="alert <?php echo e($jumlahTersedia > 0 ? 'alert-success' : 'alert-danger'); ?> d-flex align-items-center">
                                        <i
                                            class="fas <?php echo e($jumlahTersedia > 0 ? 'fa-check-circle' : 'fa-times-circle'); ?> me-2"></i>
                                        <div>
                                            <?php if($jumlahTersedia > 0): ?>
                                                <strong><?php echo e($jumlahTersedia); ?> Voucher Tersedia</strong>
                                                <div class="small">Segera lakukan pembelian sebelum voucher habis!
                                                </div>
                                            <?php else: ?>
                                                <strong>Voucher Tidak Tersedia</strong>
                                                <div class="small">Mohon maaf, voucher untuk paket ini sedang habis.
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                        <i class="fas fa-times me-2"></i>Tutup
                                    </button>
                                    <?php if($jumlahTersedia > 0): ?>
                                        <a href="<?php echo e(route('user.orders.beli', $paket->id)); ?>"
                                            class="btn btn-success">
                                            <i class="fas fa-shopping-cart me-2"></i>Beli Sekarang
                                        </a>
                                    <?php else: ?>
                                        <button class="btn btn-secondary" disabled>
                                            <i class="fas fa-ban me-2"></i>Voucher Habis
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4 mb-lg-0">
                    <h3 class="footer-title">Yusril Net</h3>
                    <p>Penyedia layanan internet berkualitas tinggi dengan harga terjangkau untuk kebutuhan pribadi
                        maupun bisnis.</p>
                    <div class="social-links mt-4">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-md-4 col-lg-2 mb-4 mb-md-0">
                    <h3 class="footer-title">Links</h3>
                    <ul class="list-unstyled">
                        <li><a href="#home" class="text-decoration-none text-white">Dashboard</a></li>
                        <li><a href="#about" class="text-decoration-none text-white">About</a></li>
                        <li><a href="#services" class="text-decoration-none text-white">Services</a></li>
                        <li><a href="#voucher" class="text-decoration-none text-white">Voucher</a></li>
                    </ul>
                </div>
                <div class="col-md-4 col-lg-3 mb-4 mb-md-0">
                    <h3 class="footer-title">Layanan</h3>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-decoration-none text-white">WiFi Publik</a></li>
                        <li><a href="#" class="text-decoration-none text-white">Solusi Bisnis</a></li>
                        <li><a href="#" class="text-decoration-none text-white">Kemitraan</a></li>
                        <li><a href="#" class="text-decoration-none text-white">Managed Service</a></li>
                    </ul>
                </div>
                <div class="col-md-4 col-lg-3">
                    <h3 class="footer-title">Kontak</h3>
                    <ul class="footer-contact">
                        <li>
                            <i class="fas fa-map-marker-alt"></i>
                            <span>Jl. Sriwijaya Gg. IX No.31, RT04/RW10, Kota
                                Bandung.</span>
                        </li>
                        <li>
                            <i class="fas fa-phone"></i>
                            <span>+62 812-3456-7890</span>
                        </li>
                        <li>
                            <i class="fas fa-envelope"></i>
                            <span>info@yusrilnet.com</span>
                        </li>
                        <li>
                            <i class="fas fa-clock"></i>
                            <span>24/7 Support</span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 Yusril Net. All rights reserved. Designed with <i class="fas fa-heart text-danger"></i>
                    for better internet experience.</p>
            </div>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <a href="#home" class="back-to-top" id="backToTop">
        <i class="fas fa-chevron-up"></i>
    </a>

    <!-- Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <!-- ... konten body lainnya ... -->

    <!-- Bootstrap JS (jika belum ada) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Script untuk Efek Scroll Navbar -->
    <script>
        const nav = document.querySelector('.navbar');
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                nav.classList.add('navbar-scrolled');
            } else {
                nav.classList.remove('navbar-scrolled');
            }
        });
    </script>

    <!-- Custom JavaScript -->
    <script>
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Back to top button functionality
        const backToTopButton = document.getElementById('backToTop');

        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 100) {
                backToTopButton.classList.add('show');
            } else {
                backToTopButton.classList.remove('show');
            }
        });

        // Navbar scroll effect
        window.addEventListener('scroll', () => {
            const navbar = document.querySelector('.navbar');
            if (window.scrollY > 50) {
                navbar.style.background = 'rgba(255, 255, 255, 0.95)';
                navbar.style.backdropFilter = 'blur(10px)';
            } else {
                navbar.style.background = 'white';
                navbar.style.backdropFilter = 'none';
            }
        });

        // Active navigation link
        window.addEventListener('scroll', () => {
            const sections = document.querySelectorAll('section');
            const navLinks = document.querySelectorAll('.nav-link');

            let current = '';
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.clientHeight;
                if (scrollY >= sectionTop - 200) {
                    current = section.getAttribute('id');
                }
            });

            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === `#${current}`) {
                    link.classList.add('active');
                }
            });
        });

        // Mobile menu close on link click
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                const navbarCollapse = document.querySelector('.navbar-collapse');
                if (navbarCollapse.classList.contains('show')) {
                    const bsCollapse = new bootstrap.Collapse(navbarCollapse);
                    bsCollapse.hide();
                }
            });
        });

        // Intersection Observer for animations
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate__animated', 'animate__fadeInUp');
                }
            });
        }, observerOptions);

        // Observe elements for animation
        document.querySelectorAll('.service-card, .pricing-card, .about-content').forEach(el => {
            observer.observe(el);
        });

        // Prevent disabled voucher purchase
        document.querySelectorAll('.pricing-btn').forEach(btn => {
            if (btn.textContent.includes('Stok Habis')) {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    alert('Maaf, voucher ini sedang tidak tersedia.');
                });
            }
        });
    </script>
</body>

</html>
<?php /**PATH C:\laragon\www\sidiknet\resources\views/welcome.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title', 'Detail Paket'); ?>

    <!-- Tombol Kembali di Pojok Kanan Atas -->
    <div class="d-flex justify-content-end mb-4">
        <a href="<?php echo e(route('admin.pakets.index')); ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left fa-sm text-white-50"></i> Kembali
        </a>
    </div>

    <div class="row">
        <!-- Kolom Kiri: Detail Utama Paket -->
        <div class="col-lg-8">
            <div class="card shadow mb-4">
                <!-- Card Header -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary"><?php echo e($paket->nama); ?></h6>
                    <span
                        class="badge <?php echo e($paket->vouchers && $paket->vouchers->count() > 0 ? 'badge-success' : 'badge-danger'); ?>">
                        <?php echo e($paket->vouchers->count()); ?> Voucher Tersedia
                    </span>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <h4 class="font-weight-bold">Rp <?php echo e(number_format($paket->price, 0, ',', '.')); ?></h4>
                    <hr>

                    <div class="mb-3">
                        <p class="font-weight-bold text-dark mb-1">
                            <i class="fas fa-info-circle fa-fw mr-2 text-gray-400"></i>Deskripsi
                        </p>
                        <p><?php echo e($paket->deskripsi); ?></p>
                    </div>

                    <div class="mb-3">
                        <p class="font-weight-bold text-dark mb-1">
                            <i class="fas fa-list-check fa-fw mr-2 text-gray-400"></i>Detail Paket
                        </p>
                        <p><?php echo e($paket->detail_paket); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Kolom Kanan: Informasi Tambahan & Aksi -->
        <div class="col-lg-4">
            <!-- Informasi Durasi -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Informasi Tambahan</h6>
                </div>
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-clock fa-2x text-gray-400"></i>
                        <div class="ml-3">
                            <div class="text-xs font-weight-bold text-uppercase mb-1">Durasi</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($paket->duration); ?> Jam</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tombol Aksi -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Tindakan</h6>
                </div>
                <div class="card-body text-center">
                    <p>Pesan paket ini sekarang juga untuk pelanggan Anda.</p>
                    <a href="#" class="btn btn-success btn-icon-split btn-block">
                        <span class="icon text-white-50">
                            <i class="fas fa-shopping-cart"></i>
                        </span>
                        <span class="text">Pesan Sekarang</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sidiknet\resources\views/pakets/show.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title', 'Voucher Management'); ?>

    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Voucher Management</h1>
            <div class="d-flex gap-2">
                <a href="<?php echo e(route('admin.vouchers.create')); ?>" class="btn btn-primary btn-sm mr-2">
                    <i class="fas fa-plus fa-sm text-white-50"></i> Tambah Voucher
                </a>
                <a href="<?php echo e(route('admin.vouchers.export')); ?>" class="btn btn-success btn-sm mr-2">
                    <i class="fas fa-download fa-sm text-white-50"></i> Export Excel
                </a>
                <a href="<?php echo e(route('admin.vouchers.import.form')); ?>" class="btn btn-info btn-sm mr-2">
                    <i class="fas fa-upload fa-sm text-white-50"></i> Import Excel
                </a>
                <a href="<?php echo e(route('admin.vouchers.template')); ?>" class="btn btn-secondary btn-sm">
                    <i class="fas fa-file-download fa-sm text-white-50"></i> Template
                </a>
            </div>
        </div>

        <!-- Alert Messages -->
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <?php if(session('warning')): ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i><?php echo e(session('warning')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <!-- Filter Card -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-filter"></i> Filter & Search
                </h6>
            </div>
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('admin.vouchers.index')); ?>">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="username" class="form-label">Username</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                                    </div>
                                    <input type="text" name="username" id="username" class="form-control"
                                        placeholder="Cari username..." value="<?php echo e(request('username')); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="paket_id" class="form-label">Paket</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fas fa-box"></i></span>
                                    </div>
                                    <select name="paket_id" id="paket_id" class="form-control">
                                        <option value="">Semua Paket</option>
                                        <?php $__currentLoopData = $pakets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($paket->id); ?>"
                                                <?php echo e(request('paket_id') == $paket->id ? 'selected' : ''); ?>>
                                                <?php echo e($paket->nama); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="status" class="form-label">Status</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fas fa-toggle-on"></i></span>
                                    </div>
                                    <select name="status" id="status" class="form-control">
                                        <option value="">Semua Status</option>
                                        <option value="aktif" <?php echo e(request('status') == 'aktif' ? 'selected' : ''); ?>>
                                            Aktif</option>
                                        <option value="nonaktif"
                                            <?php echo e(request('status') == 'nonaktif' ? 'selected' : ''); ?>>Nonaktif</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <div class="d-flex">
                                    <button type="submit" class="btn btn-primary btn-sm mr-2">
                                        <i class="fas fa-search"></i> Filter
                                    </button>
                                    <a href="<?php echo e(route('admin.vouchers.index')); ?>" class="btn btn-secondary btn-sm">
                                        <i class="fas fa-undo"></i> Reset
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Bulk Actions Card -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-tasks"></i> Bulk Actions
                </h6>
            </div>
            <div class="card-body">
                <div class="d-flex flex-wrap gap-2">
                    <button type="button" class="btn btn-warning btn-sm mr-2 mb-2" data-toggle="modal"
                        data-target="#deleteByFilterModal">
                        <i class="fas fa-filter"></i> Hapus Berdasarkan Filter
                    </button>
                    <button type="button" class="btn btn-danger btn-sm mb-2" data-toggle="modal"
                        data-target="#deleteAllModal">
                        <i class="fas fa-trash-alt"></i> Hapus Semua
                    </button>
                </div>
            </div>
        </div>

        <!-- Result Summary -->
        <?php if($vouchers->total() > 0): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i>
                Ditemukan <strong><?php echo e($vouchers->total()); ?></strong> voucher yang sesuai dengan filter
            </div>
        <?php endif; ?>

        <!-- Form untuk multiple selection -->
        <form id="deleteSelectedForm" method="POST" action="<?php echo e(route('admin.vouchers.destroySelected')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>

            <!-- DataTables -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-table"></i> Data Vouchers
                    </h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Paket</th>
                                    <th>Username</th>
                                    <th>Password</th>
                                    <th>Harga</th>
                                    <th>Durasi</th>
                                    <th>Available</th>
                                    <th>Status</th>
                                    <th>Dibuat</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($voucher->id); ?></td>
                                        <td>
                                            <span class="badge badge-info"><?php echo e($voucher->nama); ?></span>
                                        </td>
                                        <td>
                                            <code><?php echo e($voucher->username); ?></code>
                                        </td>
                                        <td>
                                            <code><?php echo e($voucher->password); ?></code>
                                        </td>
                                        <td>Rp <?php echo e(number_format($voucher->price, 0, ',', '.')); ?></td>
                                        <td><?php echo e($voucher->duration); ?> jam</td>
                                        <td>
                                            <?php if($voucher->available == 1): ?>
                                                <span class="badge badge-success">Available</span>
                                            <?php else: ?>
                                                <span class="badge badge-secondary">Used</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($voucher->status == 'aktif'): ?>
                                                <span class="badge badge-success">
                                                    <i class="fas fa-check-circle"></i> Aktif
                                                </span>
                                            <?php else: ?>
                                                <span class="badge badge-danger">
                                                    <i class="fas fa-times-circle"></i> Nonaktif
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($voucher->created_at->format('d/m/Y H:i')); ?></td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="<?php echo e(route('admin.vouchers.show', $voucher->id)); ?>"
                                                    class="btn btn-info btn-sm" title="Detail">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="<?php echo e(route('admin.vouchers.edit', $voucher->id)); ?>"
                                                    class="btn btn-warning btn-sm" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <form action="<?php echo e(route('admin.vouchers.destroy', $voucher->id)); ?>"
                                                    method="POST" style="display: inline-block;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm"
                                                        onclick="return confirm('Apakah Anda yakin ingin menghapus voucher ini?')"
                                                        title="Hapus">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="11" class="text-center">
                                            <div class="py-4">
                                                <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                                                <p class="text-muted mb-3">Tidak ada data voucher yang tersedia.</p>
                                                <a href="<?php echo e(route('admin.vouchers.create')); ?>"
                                                    class="btn btn-primary">
                                                    <i class="fas fa-plus"></i> Tambah Voucher Pertama
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <?php if($vouchers->hasPages()): ?>
                        <div class="row mt-4">
                            <div class="col-md-6">
                                <p class="text-muted">
                                    Menampilkan <strong><?php echo e($vouchers->firstItem() ?? 0); ?></strong> -
                                    <strong><?php echo e($vouchers->lastItem() ?? 0); ?></strong> dari
                                    <strong><?php echo e($vouchers->total()); ?></strong> voucher
                                </p>
                            </div>
                            <div class="col-md-6 d-flex justify-content-end">
                                <?php echo e($vouchers->withQueryString()->links()); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>

    <!-- Modal Delete All -->
    <div class="modal fade" id="deleteAllModal" tabindex="-1" role="dialog" aria-labelledby="deleteAllModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="deleteAllModalLabel">
                        <i class="fas fa-exclamation-triangle"></i> Konfirmasi Hapus Semua
                    </h5>
                    <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-3">
                        <i class="fas fa-trash-alt text-danger" style="font-size: 3rem;"></i>
                    </div>
                    <h5 class="text-center text-danger">PERINGATAN!</h5>
                    <p class="text-center">Anda akan menghapus <strong>SEMUA</strong> voucher yang ada di database.</p>
                    <p class="text-center text-muted">Tindakan ini tidak dapat dibatalkan. Apakah Anda yakin?</p>
                    <div class="alert alert-warning">
                        <i class="fas fa-info-circle"></i>
                        Total voucher yang akan dihapus: <strong><?php echo e($vouchers->total()); ?></strong>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        <i class="fas fa-times"></i> Batal
                    </button>
                    <form method="POST" action="<?php echo e(route('admin.vouchers.destroyAll')); ?>" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash-alt"></i> Ya, Hapus Semua
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Delete by Filter -->
    <div class="modal fade" id="deleteByFilterModal" tabindex="-1" role="dialog"
        aria-labelledby="deleteByFilterModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-warning text-dark">
                    <h5 class="modal-title" id="deleteByFilterModalLabel">
                        <i class="fas fa-filter"></i> Hapus Berdasarkan Filter
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="POST" action="<?php echo e(route('admin.vouchers.destroyByFilter')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <div class="modal-body">
                        <div class="text-center mb-3">
                            <i class="fas fa-filter text-warning" style="font-size: 3rem;"></i>
                        </div>
                        <h5 class="text-center text-warning">PERINGATAN!</h5>
                        <p class="text-center">Voucher akan dihapus sesuai dengan filter yang Anda pilih:</p>

                        <div class="form-group">
                            <label for="modal_status">Status</label>
                            <select name="status" id="modal_status" class="form-control">
                                <option value="">Semua Status</option>
                                <option value="aktif" <?php echo e(request('status') == 'aktif' ? 'selected' : ''); ?>>Aktif
                                </option>
                                <option value="nonaktif" <?php echo e(request('status') == 'nonaktif' ? 'selected' : ''); ?>>
                                    Nonaktif</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="modal_paket_id">Paket</label>
                            <select name="paket_id" id="modal_paket_id" class="form-control">
                                <option value="">Semua Paket</option>
                                <?php $__currentLoopData = $pakets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($paket->id); ?>"
                                        <?php echo e(request('paket_id') == $paket->id ? 'selected' : ''); ?>>
                                        <?php echo e($paket->nama); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="modal_username">Username</label>
                            <input type="text" name="username" id="modal_username" class="form-control"
                                value="<?php echo e(request('username')); ?>" placeholder="Cari berdasarkan username...">
                        </div>

                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i>
                            Filter akan diterapkan pada voucher yang akan dihapus
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            <i class="fas fa-times"></i> Batal
                        </button>
                        <button type="submit" class="btn btn-warning">
                            <i class="fas fa-filter"></i> Hapus Sesuai Filter
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const selectAllCheckbox = document.getElementById('selectAll');
                const voucherCheckboxes = document.querySelectorAll('.voucher-checkbox');
                const deleteSelectedBtn = document.getElementById('deleteSelectedBtn');
                const deleteSelectedForm = document.getElementById('deleteSelectedForm');

                // Select/Deselect All
                if (selectAllCheckbox) {
                    selectAllCheckbox.addEventListener('change', function() {
                        voucherCheckboxes.forEach(checkbox => {
                            checkbox.checked = this.checked;
                        });
                        updateDeleteSelectedButton();
                    });
                }

                // Update button status when individual checkboxes are changed
                voucherCheckboxes.forEach(checkbox => {
                    checkbox.addEventListener('change', updateDeleteSelectedButton);
                });

                // Delete selected vouchers
                if (deleteSelectedBtn) {
                    deleteSelectedBtn.addEventListener('click', function() {
                        const selectedVouchers = document.querySelectorAll('.voucher-checkbox:checked');
                        if (selectedVouchers.length > 0) {
                            if (confirm(
                                    `Yakin ingin menghapus ${selectedVouchers.length} voucher yang dipilih?`)) {
                                deleteSelectedForm.submit();
                            }
                        } else {
                            alert('Pilih minimal satu voucher untuk dihapus!');
                        }
                    });
                }

                function updateDeleteSelectedButton() {
                    const selectedVouchers = document.querySelectorAll('.voucher-checkbox:checked');

                    if (deleteSelectedBtn) {
                        deleteSelectedBtn.disabled = selectedVouchers.length === 0;

                        if (selectedVouchers.length > 0) {
                            deleteSelectedBtn.innerHTML =
                                `<i class="fas fa-trash"></i> Hapus Terpilih (${selectedVouchers.length})`;
                        } else {
                            deleteSelectedBtn.innerHTML = '<i class="fas fa-trash"></i> Hapus Terpilih';
                        }
                    }

                    // Update select all checkbox
                    if (selectedVouchers.length === voucherCheckboxes.length && voucherCheckboxes.length > 0) {
                        selectAllCheckbox.checked = true;
                        selectAllCheckbox.indeterminate = false;
                    } else if (selectedVouchers.length > 0) {
                        selectAllCheckbox.checked = false;
                        selectAllCheckbox.indeterminate = true;
                    } else {
                        selectAllCheckbox.checked = false;
                        selectAllCheckbox.indeterminate = false;
                    }
                }

                // Auto-hide alerts after 5 seconds
                setTimeout(function() {
                    const alerts = document.querySelectorAll('.alert');
                    alerts.forEach(alert => {
                        if (alert.classList.contains('show')) {
                            alert.classList.remove('show');
                            setTimeout(() => alert.remove(), 150);
                        }
                    });
                }, 5000);
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sidiknet\resources\views/vouchers/index.blade.php ENDPATH**/ ?>
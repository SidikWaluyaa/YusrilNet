<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid py-4">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Vouchers Saya</h1>
        </div>

        <div class="card shadow mb-4">
            <div class="card-body">
                <?php if($orders->isEmpty()): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-file-alt fa-3x text-primary mb-3"></i>
                        <h5 class="text-dark">Kamu belum memiliki pesanan.</h5>
                        <a href="<?php echo e(route('user.dashboard')); ?>" class="btn btn-primary mt-3">
                            <i class="fas fa-shopping-cart mr-1"></i> Beli Voucher Sekarang
                        </a>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="order-table">
                            <thead class="thead-light">
                                <tr>
                                    <th>Id</th>
                                    <th>Paket</th>
                                    <th>Harga</th>
                                    <th>Status</th>
                                    <th>Tanggal Order</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>#<?php echo e($order->id); ?></td>
                                        <td><?php echo e($order->paket->nama); ?></td>
                                        <td>Rp <?php echo e(number_format($order->harga, 0, ',', '.')); ?></td>
                                        <td>
                                            <span
                                                class="badge <?php echo e($order->status === 'terkirim' ? 'badge-success' : ($order->status === 'menunggu' ? 'badge-warning text-dark' : ($order->status === 'batal' ? 'badge-danger' : 'badge-secondary'))); ?>">
                                                <?php echo e(ucfirst($order->status)); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e($order->created_at->format('d M Y H:i')); ?></td>
                                        <td>
                                            <div class="d-flex" style="gap: 0.5rem;">
                                                <a href="<?php echo e(route('user.orders.show', $order->id)); ?>"
                                                    class="btn btn-sm btn-info" title="Lihat Detail">
                                                    <i class="fas fa-eye"></i>
                                                </a>

                                                <?php if($order->status === 'menunggu' && $order->snap_token): ?>
                                                    
                                                    <button class="btn btn-sm btn-primary pay-button"
                                                        title="Lanjutkan Pembayaran"
                                                        data-snap-token="<?php echo e($order->snap_token); ?>"
                                                        data-order-id="<?php echo e($order->id); ?>">
                                                        <i class="fas fa-credit-card"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    
    
    <?php $__env->startPush('scripts'); ?>
        <?php if($orders->isNotEmpty()): ?>
            <script src="https://app.sandbox.midtrans.com/snap/snap.js"
                data-client-key="<?php echo e(config('services.midtrans.client_key')); ?>"></script>
        <?php endif; ?>

        <script type="text/javascript">
            function updateOrderStatus(orderId, status) {
                fetch('<?php echo e(route('user.orders.updateStatus')); ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        body: JSON.stringify({
                            order_id: orderId,
                            status: status // Akan berisi 'success', 'pending', atau 'error'
                        })
                    })
                    .then(response => {
                        // Cek jika respons adalah redirect (302) yang menandakan validasi gagal
                        if (response.redirected) {
                            console.error('Validation failed. The server responded with a redirect.');
                            alert('Terjadi kesalahan validasi. Pastikan data yang dikirim sudah benar.');
                            return; // Hentikan proses lebih lanjut
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data) {
                            console.log('Server response:', data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error updating status:', error);
                        alert('Gagal mengupdate status pesanan di server. Mohon refresh halaman secara manual.');
                    });
            }

            const orderTable = document.getElementById('order-table');
            if (orderTable) {
                orderTable.addEventListener('click', function(event) {
                    const payButton = event.target.closest('.pay-button');

                    if (payButton) {
                        const snapToken = payButton.dataset.snapToken;
                        const orderId = payButton.dataset.orderId;

                        if (!snapToken || !orderId) {
                            alert("Error: Data pembayaran tidak lengkap (token atau ID pesanan hilang).");
                            return;
                        }

                        window.snap.pay(snapToken, {
                            onSuccess: function(result) {
                                // PERBAIKAN 1: Kirim 'success' agar cocok dengan validasi controller
                                updateOrderStatus(orderId, 'success');

                                // Buat URL redirect secara dinamis
                                let baseUrl = "<?php echo e(route('user.orders.show', ['id' => '__ORDER_ID__'])); ?>";
                                let destinationUrl = baseUrl.replace('__ORDER_ID__', orderId);

                                alert(
                                    'Pembayaran berhasil! Anda akan diarahkan ke halaman detail pesanan.'
                                );

                                // Beri jeda agar request update sempat terkirim, lalu redirect
                                setTimeout(function() {
                                    window.location.href = destinationUrl;
                                }, 500);
                            },
                            onPending: function(result) {
                                // PERBAIKAN 2: Kirim 'pending' agar cocok dengan validasi controller
                                updateOrderStatus(orderId, 'pending');
                                alert(
                                    "Menunggu pembayaran Anda! Halaman akan dimuat ulang untuk menampilkan status terbaru."
                                );
                                window.location.reload();
                            },
                            onError: function(result) {
                                // PERBAIKAN 3: Kirim 'error' agar cocok dengan validasi controller
                                updateOrderStatus(orderId, 'error');
                                alert("Pembayaran gagal! Halaman akan dimuat ulang.");
                                window.location.reload();
                            },
                            onClose: function() {
                                alert('Anda menutup jendela pembayaran. Status pesanan tetap menunggu.');
                            }
                        });
                    }
                });
            }
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sidiknet\resources\views/user/orders/index.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title', 'Deskripsi Paket'); ?>

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e($paket->nama); ?></h1>
        <a href="<?php echo e(route('user.dashboard')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm">
            <i class="fas fa-arrow-left fa-sm text-white-50"></i> Kembali
        </a>
    </div>

    <div class="row">
        <!-- Kolom Kiri: Detail Lengkap Paket -->
        <div class="col-lg-7">
            <div class="card shadow mb-4">
                <!-- Card Header -->
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Detail Paket</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="mb-4">
                        <h6 class="font-weight-bold">Deskripsi</h6>
                        <p><?php echo e($paket->deskripsi); ?></p>
                    </div>

                    <div>
                        <h6 class="font-weight-bold">Yang Akan Anda Dapatkan</h6>
                        <?php
                            // Tambahkan pengecekan untuk memastikan $paket->detail_paket tidak null
                            $details = $paket->detail_paket ? json_decode($paket->detail_paket) : [];
                        ?>

                        <?php if(is_array($details) && count($details) > 0): ?>
                            <ul class="list-group list-group-flush">
                                <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item d-flex align-items-center">
                                        <i class="fas fa-check-circle text-success mr-2"></i>
                                        <span><?php echo e($detail); ?></span>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <p class="text-muted">Detail tidak tersedia.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Kolom Kanan: Info Ringkas & Tombol Aksi -->
        <div class="col-lg-5">
            <!-- Card Harga & Durasi -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Informasi</h6>
                </div>
                <div class="card-body">
                    <!-- Harga -->
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span class="text-gray-600">Harga</span>
                        <span class="h5 font-weight-bold text-gray-800 mb-0">Rp
                            <?php echo e(number_format($paket->price, 0, ',', '.')); ?></span>
                    </div>
                    <hr class="my-2">
                    <!-- Durasi -->
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <span class="text-gray-600">Durasi</span>
                        <span class="font-weight-bold text-gray-800"><?php echo e($paket->duration); ?> Jam/Hari</span>
                    </div>
                </div>
            </div>

            <!-- Card Status & Aksi Beli -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Status & Pembelian</h6>
                </div>
                <div class="card-body text-center">
                    <?php
                        $jumlahTersedia = $paket->vouchers->where('status', 'aktif')->where('available', 1)->count();
                    ?>

                    <h6 class="font-weight-bold">Ketersediaan Voucher</h6>
                    <?php if($jumlahTersedia > 0): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle mr-1"></i>
                            <strong><?php echo e($jumlahTersedia); ?></strong> Voucher Tersedia
                        </div>
                        <p>Segera lakukan pembelian sebelum voucher habis.</p>
                        <a href="<?php echo e(route('user.orders.beli', $paket->id)); ?>"
                            class="btn btn-success btn-icon-split btn-block">
                            <span class="icon text-white-50">
                                <i class="fas fa-shopping-cart"></i>
                            </span>
                            <span class="text">Beli Sekarang</span>
                        </a>
                    <?php else: ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-times-circle mr-1"></i>
                            Voucher Tidak Tersedia
                        </div>
                        <p>Mohon maaf, saat ini voucher untuk paket ini sudah habis.</p>
                        <button class="btn btn-secondary btn-icon-split btn-block" disabled>
                            <span class="icon text-white-50">
                                <i class="fas fa-ban"></i>
                            </span>
                            <span class="text">Voucher Habis</span>
                        </button>
                    <?php endif; ?>
                    <a href="<?php echo e(route('user.dashboard', $paket->id)); ?>" class="btn btn-info btn-icon-split btn-block">
                        <span class="text">Kembali Ke Daftar Paket</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sidiknet\resources\views/deskripsi.blade.php ENDPATH**/ ?>
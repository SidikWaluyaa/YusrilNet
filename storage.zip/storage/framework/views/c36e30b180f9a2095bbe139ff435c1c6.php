<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('header', 'Daftar Paket Voucher'); ?>

    <div class="container-fluid">
        <div class="row mb-4">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center">
                    <h1 class="h3 text-gray-800">Daftar Paket Voucher</h1>
                    <a href="<?php echo e(route('admin.pakets.create')); ?>" class="btn btn-primary shadow-sm">
                        <i class="fas fa-plus-circle me-1"></i> Tambah Paket
                    </a>
                </div>
            </div>
        </div>

        
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card shadow">
                    <div class="card-body text-center">
                        <i class="fas fa-box fa-2x text-primary mb-2"></i>
                        <h3><?php echo e($pakets->count()); ?></h3>
                        <p class="text-muted mb-0">Total Paket</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow">
                    <div class="card-body text-center">
                        <i class="fas fa-ticket-alt fa-2x text-primary mb-2"></i>
                        <h3><?php echo e($pakets->sum(fn($p) => $p->vouchers->count())); ?></h3>
                        <p class="text-muted mb-0">Total Voucher Tersedia</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow">
                    <div class="card-body text-center">
                        <i class="fas fa-shopping-cart fa-2x text-primary mb-2"></i>
                        <h3><?php echo e($pakets->sum(fn($p) => $p->sold_count)); ?></h3>
                        <p class="text-muted mb-0">Total Terjual</p>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="card shadow mb-4">
            <div class="card-body table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="bg-primary text-white text-center">
                        <tr>
                            <th>#</th>
                            <th>Nama Paket</th>
                            <th>Harga</th>
                            <th>Durasi</th>
                            <th>Deskripsi</th>
                            <th>Detail Paket</th>
                            <th>Tersedia</th>
                            <th>Terjual</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $pakets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($paket->id); ?></td>
                                <td><?php echo e($paket->nama); ?></td>
                                <td class="text-success">Rp <?php echo e(number_format($paket->price, 0, ',', '.')); ?></td>
                                <td><?php echo e($paket->duration); ?> Jam</td>
                                <td><?php echo e(\Str::limit($paket->deskripsi, 50)); ?></td>
                                <td>
                                    <ul class="list-unstyled mb-0">
                                        <?php $details = json_decode($paket->detail_paket); ?>
                                        <?php if(is_array($details)): ?>
                                            <?php $__currentLoopData = array_slice($details, 0, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><i
                                                        class="fas fa-check-circle text-success me-1"></i><?php echo e($d); ?>

                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(count($details) > 3): ?>
                                                <li class="text-muted">+ <?php echo e(count($details) - 3); ?> lainnya</li>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <li class="text-danger">Tidak tersedia</li>
                                        <?php endif; ?>
                                    </ul>
                                </td>
                                <td class="text-center">
                                    <span
                                        class="badge <?php echo e($paket->vouchers->where('status', 'aktif')->count() > 0 ? 'bg-success' : 'bg-danger'); ?>">
                                        <?php echo e($paket->vouchers->where('status', 'aktif')->count()); ?> Voucher
                                    </span>
                                </td>
                                <td><?php echo e($paket->sold_count); ?></td>
                                <td class="text-center">
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('admin.pakets.show', $paket->id)); ?>"
                                            class="btn btn-info btn-sm" title="Lihat">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.pakets.edit', $paket->id)); ?>"
                                            class="btn btn-warning btn-sm" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('admin.pakets.destroy', $paket->id)); ?>" method="POST"
                                            onsubmit="return confirm('Yakin hapus paket ini?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-danger btn-sm" title="Hapus"><i
                                                    class="fas fa-trash"></i></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center py-5">
                                    <i class="fas fa-box-open fa-2x text-muted mb-2"></i>
                                    <p class="mb-2">Belum ada paket</p>
                                    <a href="<?php echo e(route('admin.pakets.create')); ?>" class="btn btn-primary">Tambah
                                        Paket</a>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <?php if(method_exists($pakets, 'links')): ?>
                    <div class="mt-3 d-flex justify-content-center">
                        <?php echo e($pakets->links()); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sidiknet\resources\views/pakets/index.blade.php ENDPATH**/ ?>
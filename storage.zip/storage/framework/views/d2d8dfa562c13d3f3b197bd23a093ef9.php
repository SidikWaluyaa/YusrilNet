<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid py-4">
        <!-- Heading -->
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4">
            <div>
                <h1 class="h3 text-gray-800 font-weight-bold mb-1">Paket Voucher</h1>
                <p class="mb-0 text-muted">Pilih paket voucher sesuai kebutuhanmu.</p>
            </div>
        </div>


        <!-- Card Paket -->
        <div class="row">
            <?php $__currentLoopData = $pakets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-primary shadow h-100">
                        <div class="card-body d-flex flex-column justify-content-between">
                            <div>
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <h5 class="card-title text-primary font-weight-bold mb-0"><?php echo e($paket->nama); ?></h5>
                                    <span
                                        class="badge
                                        <?php echo e($paket->vouchers->where('status', 'aktif')->count() > 0 ? 'badge-success' : 'badge-danger'); ?>">
                                        <?php echo e($paket->vouchers->where('status', 'aktif')->count()); ?> Voucher
                                    </span>
                                </div>

                                <div class="mb-3">
                                    <h4 class="text-dark font-weight-bold">Rp
                                        <?php echo e(number_format($paket->price, 0, ',', '.')); ?></h4>
                                    <p class="text-muted small"><?php echo e($paket->deskripsi); ?></p>
                                </div>

                                <ul class="list-unstyled small mb-3">
                                    <?php $__currentLoopData = json_decode($paket->detail_paket); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="mb-1">
                                            <i class="fas fa-check text-success mr-2"></i> <?php echo e($detail); ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>

                            <div class="d-grid gap-2">
                                <a href="<?php echo e(route('user.deskripsi', $paket->id)); ?>"
                                    class="btn btn-outline-primary btn-sm">
                                    <i class="fas fa-info-circle mr-1"></i>Deskripsi
                                </a>
                                <a href="<?php echo e(route('user.orders.beli', $paket->id)); ?>" class="btn btn-primary btn-sm">
                                    <i class="fas fa-shopping-cart mr-1"></i>Beli Voucher
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sidiknet\resources\views/user/dashboard.blade.php ENDPATH**/ ?>